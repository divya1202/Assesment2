package com.lti.eurekaserverApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaserverAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
